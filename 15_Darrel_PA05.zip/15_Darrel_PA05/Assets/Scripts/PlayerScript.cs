﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PlayerScript : MonoBehaviour
{
    public float speed;
    private float score = 0;
    Rigidbody playerigidbody;
    public Text Score;
    // Start is called before the first frame update
    void Start()
    {
        playerigidbody = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        float movehorizontal = Input.GetAxis("Horizontal");
        float movevertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(movehorizontal, 0, movevertical);
        playerigidbody.AddForce(movement * speed * Time.deltaTime);

        Score.text = "Score: " + score;
        if (score == 4)
        {
            SceneManager.LoadScene("Win");
        }
    }
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Coin")
        {
            score++;
            Destroy(collision.gameObject);
        }

        if (collision.gameObject.tag == "Hazard")
        {
            SceneManager.LoadScene("Lose");
        }
    }
}

